export const FALLBACK_SUMMARY = {
  alerts_total: 88,
  alerts_high: 18,
  alerts_medium: 3,
  alerts_low: 67,
  queries_total: 4920,
  queries_lifetime: 4920,
  queries_suspicious: 30,
  unique_hosts: 9,
  tests_total: 18,
  tests_passed: 18,
  tests_ok: true,
  mode: "DEMO_FEED",
  data_source: "synthetic",
}

export const FALLBACK_ALERTS = [
  {
    alert_id: "A7F2C1",
    src_host: "10.0.0.99",
    domain: "labdomain.internal",
    severity: "HIGH",
    total_score: 93,
    timestamp: new Date().toISOString(),
    is_beaconing: 1,
    reasons: [
      "[Rule R001] Abnormally long query (91 chars)",
      "[Rule R002] High subdomain entropy (4.21)",
      "[Behavior] Regular C2 beacon every ~15s | score: 0.94",
      "[ML] Malicious probability: 91.3%",
    ],
  },
]

export const FALLBACK_CHARTS = {
  traffic: [
    { time: "14:01", normal: 11, suspicious: 2 },
    { time: "14:02", normal: 13, suspicious: 3 },
    { time: "14:03", normal: 12, suspicious: 2 },
    { time: "14:04", normal: 15, suspicious: 4 },
  ],
  entropy_distribution: [
    { bin: "0.0-0.8", normal: 24, suspicious: 0 },
    { bin: "0.8-1.6", normal: 45, suspicious: 1 },
    { bin: "1.6-2.4", normal: 22, suspicious: 2 },
    { bin: "2.4-3.2", normal: 3, suspicious: 7 },
    { bin: "3.2-4.0", normal: 0, suspicious: 13 },
  ],
  query_length_distribution: [
    { bin: "10-16", normal: 42, suspicious: 0 },
    { bin: "16-22", normal: 37, suspicious: 1 },
    { bin: "22-28", normal: 9, suspicious: 3 },
    { bin: "28-34", normal: 1, suspicious: 8 },
    { bin: "34-40", normal: 0, suspicious: 12 },
  ],
  severity_breakdown: [
    { name: "HIGH", value: 3 },
    { name: "MEDIUM", value: 3 },
    { name: "LOW", value: 67 },
  ],
  attack_type_breakdown: [
    { type: "Beaconing", count: 22 },
    { type: "Exfiltration/Tunneling", count: 8 },
    { type: "DGA Sweep", count: 6 },
  ],
  top_hosts: [
    { host: "10.0.0.99", score: 93 },
    { host: "10.0.0.8", score: 26 },
    { host: "10.0.0.4", score: 19 },
  ],
}

export const FALLBACK_QUERIES = [
  {
    timestamp: new Date().toISOString(),
    src_ip: "10.0.0.99",
    query_name: "chunk17.dGhpcyBpcyBhIHNlY3JldA==.labdomain.internal",
    query_type: 16,
    rcode: 3,
    label: 1,
    status: "suspicious",
  },
]
