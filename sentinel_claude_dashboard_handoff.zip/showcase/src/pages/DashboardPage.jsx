import { useEffect, useMemo, useRef, useState } from "react"
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { useAlerts, useCharts, useQueries, useRealtimeSignals, useSummary } from "../api/useApi"
import AlertCard from "../components/AlertCard"
import ChartPanel from "../components/ChartPanel"
import KPI from "../components/KPI"
import Nav from "../components/Nav"
import { FALLBACK_ALERTS, FALLBACK_CHARTS, FALLBACK_QUERIES, FALLBACK_SUMMARY } from "../data/staticData"
import { T } from "../styles/theme"

function EmptyState({ text = "No data available" }) {
  return (
    <div
      style={{
        minHeight: 180,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: T.muted,
        fontSize: 11,
        letterSpacing: ".12em",
      }}
    >
      {text}
    </div>
  )
}

function formatLocalTime(iso) {
  if (!iso) return "--:--:--"
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return "--:--:--"
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
}

export default function DashboardPage({ onNavigate }) {
  const summaryQ = useSummary()
  const chartsQ = useCharts()
  const alertsQ = useAlerts()
  const queriesQ = useQueries()
  const realtimeQ = useRealtimeSignals()

  const summary = realtimeQ.summary || summaryQ.data || FALLBACK_SUMMARY
  const charts = chartsQ.data || FALLBACK_CHARTS
  const alerts = alertsQ.data || FALLBACK_ALERTS
  const queries = queriesQ.data || FALLBACK_QUERIES
  const [liveAlerts, setLiveAlerts] = useState(alerts)
  const notifiedIds = useRef(new Set())

  useEffect(() => {
    setLiveAlerts(alerts)
  }, [alerts])

  useEffect(() => {
    if (!Array.isArray(realtimeQ.newAlerts) || realtimeQ.newAlerts.length === 0) return
    setLiveAlerts((prev) => {
      const merged = [...realtimeQ.newAlerts, ...(Array.isArray(prev) ? prev : [])]
      const byId = new Map()
      for (const item of merged) {
        const id = item?.alert_id || `${item?.src_host || "x"}-${item?.domain || "y"}-${item?.timestamp || Date.now()}`
        if (!byId.has(id)) byId.set(id, item)
      }
      return Array.from(byId.values()).slice(0, 50)
    })
  }, [realtimeQ.newAlerts])

  useEffect(() => {
    if (!Array.isArray(realtimeQ.newAlerts) || realtimeQ.newAlerts.length === 0) return
    if (typeof window === "undefined" || !("Notification" in window)) return

    if (Notification.permission === "default") {
      Notification.requestPermission().catch(() => {})
    }
    if (Notification.permission !== "granted") return

    for (const a of realtimeQ.newAlerts) {
      const id = a?.alert_id || `${a?.src_host || "x"}-${a?.domain || "y"}`
      if (notifiedIds.current.has(id)) continue
      notifiedIds.current.add(id)
      if (String(a?.severity || "").toUpperCase() !== "HIGH") continue

      const score = Number(a?.total_score || 0).toFixed(1)
      const body = `${a?.src_host || "unknown"} -> ${a?.domain || "unknown"} | score ${score}`
      try {
        new Notification("SENTINEL HIGH ALERT", { body })
      } catch (_) {}
    }
  }, [realtimeQ.newAlerts])

  const severityData = (charts?.severity_breakdown || []).map((x) => ({
    ...x,
    color: x.name === "HIGH" ? T.r : x.name === "MEDIUM" ? T.o : T.g2,
  }))

  const attackTypes = charts?.attack_type_breakdown || []
  const topHosts = charts?.top_hosts || []
  const traffic = charts?.traffic || []
  const entropyDist = charts?.entropy_distribution || []
  const queryLengthDist = charts?.query_length_distribution || []

  const trafficSeriesRaw = traffic.map((row) => ({
    ...row,
    time_local: row?.ts_utc ? formatLocalTime(row.ts_utc).slice(0, 5) : row?.time || "--:--",
  }))

  const trafficSeries = trafficSeriesRaw.length === 1
    ? [{ time_local: "prev", normal: 0, suspicious: 0 }, trafficSeriesRaw[0]]
    : trafficSeriesRaw

  const tooltipStyle = {
    background: T.s2,
    border: `1px solid ${T.brd}`,
    borderRadius: 4,
    fontFamily: "'Share Tech Mono', 'Courier New', monospace",
    fontSize: 11,
    color: T.txt,
  }

  const streamAgeSec = useMemo(
    () => (realtimeQ.lastEventTs ? Math.max(0, Math.round((Date.now() - realtimeQ.lastEventTs) / 1000)) : null),
    [realtimeQ.lastEventTs],
  )

  const anyError = summaryQ.error || chartsQ.error || alertsQ.error || queriesQ.error

  return (
    <div style={{ color: T.txt, background: T.bg, minHeight: "100vh" }}>
      <Nav
        page="dashboard"
        onNavigate={onNavigate}
        liveQueries={summary?.queries_total || 0}
        lifetimeQueries={summary?.queries_lifetime || 0}
        mode={summary?.mode || "DEMO_FEED"}
      />

      <div style={{ padding: "24px" }}>
        <div
          style={{
            marginBottom: 12,
            padding: "8px 12px",
            borderRadius: 4,
            border: `1px solid ${realtimeQ.connected ? T.g1 : T.o}`,
            background: realtimeQ.connected ? `${T.g1}14` : `${T.o}12`,
            color: realtimeQ.connected ? T.g1 : T.o,
            display: "flex",
            alignItems: "center",
            gap: 10,
            fontSize: 11,
            letterSpacing: ".08em",
          }}
        >
          <span className="pulse-dot" style={{ width: 7, height: 7, borderRadius: "50%", background: realtimeQ.connected ? T.g1 : T.o }} />
          <span>{realtimeQ.connected ? "REALTIME SIGNAL STREAM ONLINE" : "REALTIME STREAM RECONNECTING (poll fallback active)"}</span>
          <span style={{ marginLeft: "auto", color: T.muted }}>
            {streamAgeSec === null ? "waiting first event" : `last stream event ${streamAgeSec}s ago`}
          </span>
        </div>

        {anyError && (
          <div style={{ marginBottom: 16, padding: 10, border: `1px solid ${T.r}`, color: T.r, background: `${T.r}12` }}>
            API error detected. Dashboard is currently using fallback/cached values where needed.
          </div>
        )}

        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, minmax(120px,1fr))", gap: 12, marginBottom: 16 }}>
          <KPI
            label="QUERIES (WINDOW)"
            value={(summary?.queries_total || 0).toLocaleString()}
            color={T.g1}
            sub={`lifetime ${(summary?.queries_lifetime || 0).toLocaleString()}`}
          />
          <KPI label="SUSPICIOUS" value={(summary?.queries_suspicious || 0).toLocaleString()} color={T.o} />
          <KPI label="ALERTS" value={(summary?.alerts_total || 0).toLocaleString()} color={T.r} />
          <KPI label="HIGH ALERTS" value={(summary?.alerts_high || 0).toLocaleString()} color={T.r} />
          <KPI label="HOSTS" value={(summary?.unique_hosts || 0).toLocaleString()} color={T.b} />
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 12, marginBottom: 16 }}>
          <ChartPanel title="DNS TRAFFIC OVER TIME" error={chartsQ.error} lastOk={chartsQ.lastOk} loading={chartsQ.loading}>
            {trafficSeries.length ? (
              <div style={{ height: 240 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trafficSeries}>
                    <CartesianGrid stroke={T.brd} strokeDasharray="2 3" />
                    <XAxis dataKey="time_local" stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} />
                    <YAxis stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Area type="monotone" dataKey="normal" stroke={T.g1} fill={`${T.g1}33`} />
                    <Area type="monotone" dataKey="suspicious" stroke={T.r} fill={`${T.r}33`} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <EmptyState text="Waiting for traffic data" />
            )}
          </ChartPanel>

          <div style={{ display: "grid", gridTemplateRows: "1fr 1fr", gap: 12 }}>
            <ChartPanel title="SEVERITY BREAKDOWN" error={chartsQ.error} lastOk={chartsQ.lastOk} loading={chartsQ.loading}>
              {severityData.length ? (
                <div style={{ height: 220 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={severityData} dataKey="value" nameKey="name" outerRadius={80}>
                        {severityData.map((entry) => (
                          <Cell key={entry.name} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip contentStyle={tooltipStyle} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <EmptyState text="No severity data" />
              )}
            </ChartPanel>

            <ChartPanel title="TOP HOSTS" error={chartsQ.error} lastOk={chartsQ.lastOk} loading={chartsQ.loading}>
              {topHosts.length ? (
                <div style={{ height: 220 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={topHosts} layout="vertical" margin={{ left: 20 }}>
                      <CartesianGrid stroke={T.brd} strokeDasharray="2 3" />
                      <XAxis type="number" stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} />
                      <YAxis dataKey="host" type="category" stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} width={95} />
                      <Tooltip contentStyle={tooltipStyle} />
                      <Bar dataKey="score" fill={T.b} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <EmptyState text="No host scores" />
              )}
            </ChartPanel>
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
          <ChartPanel title="SUBDOMAIN ENTROPY DISTRIBUTION" error={chartsQ.error} lastOk={chartsQ.lastOk} loading={chartsQ.loading}>
            {entropyDist.length ? (
              <div style={{ height: 220 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={entropyDist}>
                    <CartesianGrid stroke={T.brd} strokeDasharray="2 3" />
                    <XAxis dataKey="bin" stroke={T.muted} tick={{ fill: T.muted, fontSize: 9 }} />
                    <YAxis stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Bar dataKey="normal" fill={T.g1} />
                    <Bar dataKey="suspicious" fill={T.r} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <EmptyState text="No entropy data" />
            )}
          </ChartPanel>

          <ChartPanel title="QUERY LENGTH DISTRIBUTION" error={chartsQ.error} lastOk={chartsQ.lastOk} loading={chartsQ.loading}>
            {queryLengthDist.length ? (
              <div style={{ height: 220 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={queryLengthDist}>
                    <CartesianGrid stroke={T.brd} strokeDasharray="2 3" />
                    <XAxis dataKey="bin" stroke={T.muted} tick={{ fill: T.muted, fontSize: 9 }} />
                    <YAxis stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} />
                    <Tooltip contentStyle={tooltipStyle} />
                    <Bar dataKey="normal" fill={T.g3} />
                    <Bar dataKey="suspicious" fill={T.o} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <EmptyState text="No length distribution data" />
            )}
          </ChartPanel>
        </div>

        <ChartPanel title="ATTACK TYPE BREAKDOWN" error={chartsQ.error} lastOk={chartsQ.lastOk} loading={chartsQ.loading}>
          {attackTypes.length ? (
            <div style={{ height: 220 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={attackTypes} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid stroke={T.brd} strokeDasharray="2 3" />
                  <XAxis type="number" stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} />
                  <YAxis dataKey="type" type="category" stroke={T.muted} tick={{ fill: T.muted, fontSize: 10 }} width={130} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Bar dataKey="count" fill={T.o} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <EmptyState text="No attack type data" />
          )}
        </ChartPanel>

        <div style={{ background: T.s1, border: `1px solid ${T.brd}`, borderRadius: 4, padding: 18, marginTop: 16, marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontSize: 10, color: T.muted, letterSpacing: ".16em" }}>ALERTS</div>
            <div style={{ marginLeft: "auto", fontSize: 10, color: realtimeQ.newAlerts?.length ? T.o : T.muted }}>
              new signals: {realtimeQ.newAlerts?.length || 0}
            </div>
          </div>
          {liveAlerts.length === 0 && <div style={{ color: T.muted, fontSize: 12 }}>No alerts yet</div>}
          {liveAlerts.map((a, idx) => (
            <AlertCard key={a.alert_id || `${a.src_host}-${idx}`} alert={a} defaultOpen={idx === 0} />
          ))}
        </div>

        <div style={{ background: T.s1, border: `1px solid ${T.brd}`, borderRadius: 4, padding: 18 }}>
          <div style={{ fontSize: 10, color: T.muted, letterSpacing: ".16em", marginBottom: 12 }}>DNS QUERY LOG (LATEST)</div>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11 }}>
              <thead>
                <tr>
                  {["Time", "Source", "Query", "Type", "RCode", "Status"].map((h) => (
                    <th key={h} style={{ textAlign: "left", padding: "8px 6px", color: T.muted, borderBottom: `1px solid ${T.brd}` }}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {queries.map((q, idx) => (
                  <tr key={`${q.timestamp}-${idx}`}>
                    <td style={{ padding: "8px 6px", borderBottom: `1px solid ${T.brd}55` }}>
                      {formatLocalTime(q.timestamp_utc || q.timestamp)}
                    </td>
                    <td style={{ padding: "8px 6px", borderBottom: `1px solid ${T.brd}55` }}>{q.src_ip}</td>
                    <td style={{ padding: "8px 6px", borderBottom: `1px solid ${T.brd}55`, color: q.status === "suspicious" ? T.r : T.txt }}>
                      {q.query_name}
                    </td>
                    <td style={{ padding: "8px 6px", borderBottom: `1px solid ${T.brd}55` }}>{q.query_type}</td>
                    <td style={{ padding: "8px 6px", borderBottom: `1px solid ${T.brd}55` }}>{q.rcode}</td>
                    <td style={{ padding: "8px 6px", borderBottom: `1px solid ${T.brd}55`, color: q.status === "suspicious" ? T.r : T.g1 }}>
                      {q.status}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
