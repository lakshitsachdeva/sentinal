import { useState } from "react"
import { ChevronDown, ChevronRight } from "lucide-react"
import { T } from "../styles/theme"
import Badge from "./Badge"

function normalizeReasons(reasons) {
  if (Array.isArray(reasons)) return reasons
  if (typeof reasons === "string") {
    try {
      const parsed = JSON.parse(reasons)
      return Array.isArray(parsed) ? parsed : [reasons]
    } catch {
      return [reasons]
    }
  }
  return []
}

export default function AlertCard({ alert, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen)
  const severity = String(alert?.severity || "LOW").toUpperCase()
  const c = severity === "HIGH" ? T.r : severity === "MEDIUM" ? T.o : T.g2
  const reasons = normalizeReasons(alert?.reasons)

  return (
    <div
      style={{
        border: `1px solid ${c}33`,
        borderLeft: `3px solid ${c}`,
        borderRadius: 4,
        marginBottom: 8,
        background: `${c}08`,
        overflow: "hidden",
      }}
    >
      <div
        onClick={() => setOpen((v) => !v)}
        style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", cursor: "pointer" }}
      >
        <span style={{ color: c, fontSize: 11, fontWeight: 700, minWidth: 64 }}>[{severity}]</span>
        <span style={{ color: T.txt, fontSize: 12, flex: 1 }}>
          {alert?.src_host || "-"} -&gt; {alert?.domain || "-"}
        </span>
        <span style={{ color: c, fontSize: 15, fontWeight: 700 }}>
          {Number(alert?.total_score || 0).toFixed(1)}/100
        </span>
        {open ? <ChevronDown size={13} color={T.muted} /> : <ChevronRight size={13} color={T.muted} />}
      </div>

      {open && (
        <div style={{ padding: "0 14px 14px", borderTop: `1px solid ${c}1a` }}>
          <div style={{ display: "flex", gap: 8, marginTop: 10, marginBottom: 8 }}>
            <Badge color={c}>{severity}</Badge>
            <Badge color={alert?.is_beaconing ? T.o : T.g4}>{alert?.is_beaconing ? "BEACONING" : "NON-BEACON"}</Badge>
            {alert?.run_id && <Badge color={T.b}>{String(alert.run_id)}</Badge>}
          </div>
          {reasons.length ? (
            <div style={{ fontSize: 11 }}>
              {reasons.slice(0, 8).map((r, i) => (
                <div key={i} style={{ padding: "5px 0", borderBottom: `1px solid ${T.brd}33`, color: T.txt }}>
                  {'>'} {r}
                </div>
              ))}
            </div>
          ) : (
            <div style={{ fontSize: 11, color: T.muted }}>No evidence reasons available.</div>
          )}
        </div>
      )}
    </div>
  )
}
