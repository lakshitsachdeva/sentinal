import { Shield } from "lucide-react"
import { useEffect, useState } from "react"
import { T } from "../styles/theme"

function ModeLabel({ mode }) {
  const isLive = mode === "LIVE_CAPTURE"
  return (
    <span
      style={{
        padding: "2px 8px",
        borderRadius: 2,
        fontSize: 9,
        letterSpacing: ".15em",
        background: isLive ? `${T.r}18` : `${T.g4}40`,
        border: `1px solid ${isLive ? T.r : T.g4}`,
        color: isLive ? T.r : T.muted,
      }}
    >
      {isLive ? "LIVE CAPTURE" : "DEMO FEED"}
    </span>
  )
}

function Clock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])
  return (
    <span style={{ color: T.muted, fontSize: 10, letterSpacing: ".08em" }}>
      {now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
    </span>
  )
}

export default function Nav({ page, onNavigate, liveQueries = 0, lifetimeQueries = 0, mode = "DEMO_FEED" }) {
  return (
    <nav
      style={{
        position: "sticky",
        top: 0,
        zIndex: 100,
        padding: "11px 24px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        background: `${T.s1}f0`,
        borderBottom: `1px solid ${T.brd}`,
        backdropFilter: "blur(12px)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        {page !== "landing" && (
          <button className="nav-btn" onClick={() => onNavigate("landing")}>
            HOME
          </button>
        )}
        <Shield size={17} color={T.g1} />
        <span style={{ color: T.g1, fontSize: 14, letterSpacing: ".22em", fontWeight: 700 }}>SENTINEL</span>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <ModeLabel mode={mode} />
        <Clock />
        <span style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11, color: T.g1 }}>
          <span
            className="pulse-dot"
            style={{ width: 7, height: 7, borderRadius: "50%", background: T.g1, display: "inline-block" }}
          />
          {(liveQueries || 0).toLocaleString()} window
        </span>
        <span style={{ fontSize: 10, color: T.muted }}>
          {(lifetimeQueries || 0).toLocaleString()} lifetime
        </span>
        {page !== "dashboard" && (
          <button className="nav-btn" onClick={() => onNavigate("dashboard")}>
            DASHBOARD
          </button>
        )}
        {page !== "architecture" && (
          <button className="nav-btn" onClick={() => onNavigate("architecture")}>
            ARCHITECTURE
          </button>
        )}
      </div>
    </nav>
  )
}
