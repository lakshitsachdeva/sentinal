import ApiStatus from "./ApiStatus"
import { T } from "../styles/theme"

export default function ChartPanel({ title, subtitle, error, lastOk, loading, minHeight = 220, children }) {
  return (
    <div
      style={{
        background: T.s1,
        border: `1px solid ${T.brd}`,
        borderRadius: 4,
        padding: 18,
      }}
    >
      <div style={{ fontSize: 10, color: T.muted, letterSpacing: ".16em", marginBottom: 4 }}>{title}</div>
      {subtitle && <div style={{ fontSize: 10, color: T.g4, marginBottom: 12 }}>{subtitle}</div>}
      <ApiStatus error={error} lastOk={lastOk} label={title} />
      {loading && !error ? (
        <div
          style={{
            minHeight,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: T.muted,
            fontSize: 11,
            letterSpacing: ".14em",
          }}
        >
          <span className="blink">LOADING</span>
        </div>
      ) : (
        children
      )}
    </div>
  )
}
