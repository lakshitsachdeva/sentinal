import { T } from "../styles/theme"

export default function KPI({ label, value, color = T.g1, sub }) {
  return (
    <div
      style={{
        padding: "16px 20px",
        background: T.s2,
        border: `1px solid ${T.brd}`,
        borderTop: `2px solid ${color}`,
        borderRadius: 4,
      }}
    >
      <div style={{ fontSize: 10, color: T.muted, letterSpacing: ".12em", marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 700, color, lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 10, color: T.muted, marginTop: 4 }}>{sub}</div>}
    </div>
  )
}
